package exe.gba.equacaodosegundograu;

public class Teste {
    public static void main(String[] args) {
        EquacaoDoSegundoGrau equacao = new EquacaoDoSegundoGrau(1,2,2);

        System.out.println(equacao.calcularRaizes());
    }
}
